<?php
$field_name = $_POST['name'];
$field_email = $_POST['email'];
$field_Phoneno = $_POST['phone'];
$field_message = $_POST['query'];



$mail_to = 'navneet.navan@gmail.com.com';
$header = "Cc:navneet@230thk.com \r\n";
$subject = 'Contact form enquery - TIS landing page ';


$body_message = 'From: '.$field_name."\n";
$body_message .= 'E-mail: '.$field_email."\n";
$body_message .= 'Phone No: '.$field_Phoneno."\n";
$body_message .= 'Customer Query: '.$field_message."\n";



$headers = 'From: '.$field_email."\r\n";
$headers .= 'Reply-To: '.$field_email."\r\n";
$headers .= "Cc:navneet@theinsidestuff.com \r\n";

$mail_status = mail($mail_to, $subject, $body_message, $headers);

if ($mail_status) { ?>
	<script language="javascript" type="text/javascript">
		alert('Thank you for the message. We will contact you shortly.');
		 window.location = 'http://theinsidestuff.com/';
	</script>
<?php
}
else { ?>
	<script language="javascript" type="text/javascript">
		alert('Message failed. Please, send an email to pratima@230thk.com');
		 window.location = 'http://theinsidestuff.com/';
	</script>
<?php
}
?>